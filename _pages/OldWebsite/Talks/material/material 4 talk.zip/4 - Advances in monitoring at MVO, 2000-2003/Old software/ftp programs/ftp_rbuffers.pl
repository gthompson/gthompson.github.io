#!e:\bin\perl
# ftp_rbuffers.pl
# Glenn Thompson, October 2000
# This script compares current ut time with last rbuffer
# transfered from the VME, writes an ftp script to transfer
# all rbuffers recorded since, and then executes that ftp script

# Set up
use lib "E:\\SEISMO\PERLPROGS";
use perlutils qw(get_time);
use FileHandle;
require("paths.pl");
$lastrbufferfile="$rbuffersPATH\\lastrbuffer.dat";
$filenrlis="$rbuffersPATH\\filenr.lis";

# read in last rbuffer file transfered
$fl=new FileHandle "$lastrbufferfile";
unless (defined($fl)) {
	die("Cannot read $lastrbufferfile\n");
}
read($fl,$lastrbuffer,12);
close($fl);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
$lYY=substr($lastrbuffer,0,2);
$lMM=substr($lastrbuffer,2,2);
$lDD=substr($lastrbuffer,5,2);
$lHH=substr($lastrbuffer,8,2);

# open vme_rbuffers.ftp for output
$FTPscript="$ftpPATH\\ftp_rbuffers.ftp";
$fh=new FileHandle ">$FTPscript";
unless (defined($fh)) {
	die("Could not open $FTPscript for output\n");
}

# write ftp commands
print $fh "seismo\nseismo\n";
print $fh "cd /dd/buffer\n";
print $fh "lcd $rbuffersPATH\n";
print $fh "prompt off\n";
print $fh "bin\n";
$daysago=0;($yy,$mm,$dd,$hh,$mi)=get_time("ut",$daysago);$yy=$yy-1908;
while ( ($yy!=$lYY) | ($mm!=$lMM) | ($dd!=$lDD) | ($hh!=$lHH) ) {
	$getstring="$yy" . "$mm" . "_$dd" . "_$hh*";
	print $fh "mget $getstring\n";
	$daysago+=1/24;
	($yy,$mm,$dd,$hh,$mi)=get_time("ut",$daysago);$yy=$yy-1908;
}
$getstring="$lYY" . "$lMM" . "_$lDD" . "_$lHH*";
print $fh "mget $getstring\n";
print $fh "bye\n";
close($fh);

# run ftp script
system("ftp -s:$FTPscript 192.123.0.87");

# update lastrbuffer
opendir THISDIR, $rbuffersPATH;
@allfiles=readdir THISDIR;
$count=-1;
foreach $file (@allfiles) {
	if (substr($file,0,1) eq "9") {
		$count++;
		$rbuffers[$count]=$file;
		print "rbuffer file # $count is $rbuffers[$count]\n";
		if ($file gt $lastrbuffer) {
			$lastrbuffer = $file;
		}
	}
}
$fl=new FileHandle ">$lastrbufferfile";
unless (defined($fl)) {
	die("Cannot update $lastrbufferfile\n");
}
print $fl "$lastrbuffer\n";
close($fl);   

# apply Y2K patches to Seislog files & demux
chdir("$rbuffersPATH");
system("cd $rbuffersPATH");
foreach $rbuffer (@rbuffers) {
	print "Processing $rbuffer\n";
	$yy=substr($rbuffer,0,2);
	$therest=substr($rbuffer,2,23);
	$yy-=92;
	while (length($yy)<2) {
		$yy="0" . "$yy";
	}
	$y2krbuffer = "$yy" . "$therest";
	print "Moving to $y2krbuffer\n";
	$daydir=substr($y2krbuffer,0,7);
	unless (-e "$archivePATH\\rbuffers\\$daydir") {
		mkdir("$archivePATH\\rbuffers\\$daydir");
	}
	system("move $rbuffer $archivePATH\\rbuffers\\$daydir\\$y2krbuffer");
}


