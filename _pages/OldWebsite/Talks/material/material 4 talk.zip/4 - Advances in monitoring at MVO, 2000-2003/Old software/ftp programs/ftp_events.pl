#!e:\bin\perl
# ftp_events.pl
# Glenn Thompson, September 2000
# This script compares current ut time with last event
# transfered from the VME, writes an ftp script to transfer
# all events recorded since, and then executes that ftp script

# Set up
use lib "E:\\SEISMO\PERLPROGS";
use perlutils qw(get_time);
use FileHandle;
require("paths.pl");
$lasteventfile="$os9eventsPATH\\lastevent.dat";
$filenrlis="$os9eventsPATH\\filenr.lis";

# read in last event file transfered
$fl=new FileHandle "$lasteventfile";
unless (defined($fl)) {
	die("Cannot read $lasteventfile\n");
}
read($fl,$lastevent,12);
close($fl);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
$lYY=substr($lastevent,0,2);
$lMM=substr($lastevent,2,2);
$lDD=substr($lastevent,5,2);
$lHH=substr($lastevent,8,2);

# open vme_events.ftp for output
$FTPscript="$ftpPATH\\ftp_events.ftp";
$fh=new FileHandle ">$FTPscript";
unless (defined($fh)) {
	die("Could not open $FTPscript for output\n");
}

# write ftp commands
print $fh "seismo\nseismo\n";
print $fh "cd /dd/events\n";
print $fh "lcd $os9eventsPATH\n";
print $fh "prompt off\n";
print $fh "bin\n";
$daysago=0;($yy,$mm,$dd,$hh,$mi)=get_time("ut",$daysago);$yy=$yy-1908;
while ( ($yy!=$lYY) | ($mm!=$lMM) | ($dd!=$lDD) | ($hh!=$lHH) ) {
	$getstring="$yy" . "$mm" . "_$dd" . "_$hh*";
	print $fh "mget $getstring\n";
	$daysago+=1/24;
	($yy,$mm,$dd,$hh,$mi)=get_time("ut",$daysago);$yy=$yy-1908;
}
$getstring="$lYY" . "$lMM" . "_$lDD" . "_$lHH*";
print $fh "mget $getstring\n";
print $fh "bye\n";
close($fh);

# run ftp script
system("ftp -s:$FTPscript 192.123.0.87");

# update lastevent
opendir THISDIR, $os9eventsPATH;
@allfiles=readdir THISDIR;
$count=-1;
foreach $file (@allfiles) {
	if (substr($file,0,1) eq "9") {
		$count++;
		$os9events[$count]=$file;
		print "os9event file # $count is $os9events[$count]\n";
		if ($file gt $lastevent) {
			$lastevent = $file;
		}
	}
}
$fl=new FileHandle ">$lasteventfile";
unless (defined($fl)) {
	die("Cannot update $lasteventfile\n");
}
print $fl "$lastevent\n";
close($fl);   

# apply Y2K patches to Seislog files & demux
chdir("$os9eventsPATH");
system("cd $os9eventsPATH");
system("dir");
system("copy $seisanprogs\\os9sei.exe $os9eventsPATH");
foreach $os9event (@os9events) {
	print "Processing $os9event\n";
	$yy=substr($os9event,0,2);
	$therest=substr($os9event,2,23);
	$yy-=92;
	while (length($yy)<2) {
		$yy="0" . "$yy";
	}
	$y2kevent = "$yy" . "$therest";
	print "Moving to $y2kevent\n";
	system("move $os9event $y2kevent");
	print "demultiplexing $y2kevent\n";
	system("os9sei $y2kevent");
	print "Removing $y2kevent\n\n";
	system("del $y2kevent");
}

# apply Y2K patches to seisan event files
opendir THISDIR, $os9eventsPATH;
@allfiles=readdir THISDIR;
foreach $file (@allfiles) {
	print "$file\n";
	if (substr($file,0,3) eq "199") {
		print "Processing $file\n";
		$yyyy=substr($file,0,4);
		$therest=substr($file,4,25);
		$yyyy+=8;
		$y2kevent = "$yyyy" . "$therest";
		print "Renaming $file to $y2kevent\n";
		system("move $file $y2kevent");
		print "Copying $y2kevent to WAV directory\n";
		system("copy $y2kevent $WAVpath\\$y2kevent");
		print "Moving $y2kevent to ARCHIVE directory\n";
		$daydir=substr($y2kevent,0,10);
		unless (-e "$archivePATH\\events\\$daydir") {
			mkdir("$archivePATH\\events\\$daydir");
		}
		system("move $y2kevent $archivePATH\\events\\$daydir");
	}
}



