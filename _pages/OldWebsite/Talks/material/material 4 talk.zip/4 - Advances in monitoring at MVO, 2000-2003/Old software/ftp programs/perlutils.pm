package perlutils;
require Exporter;
@ISA=qw(Exporter);
@EXPORT=qw(get_time date2dnum return_plot_limits cumulate_data subclass2eventtype calc_xinterval add_barwidth_column days_per_year dnum2yyyy dnum2date yyyy2yy yy2yyyy days_per_month date2dnum);
@EXPORT_OK=qw($year $mon $mday $hour $min $dnum $minx $maxx $miny $maxy $total $eventtype $xinterval $ndays $yyyy $yy $mm $dd $hh $mn $ss);

##############################################################################################

# to get local (Montserrat) or UT time in Y2K compatible form
# Usage: ($year,$mon,$mday,$hour,$min)=get_time($zone,$days_ago);

sub get_time {
	($zone,$days_ago)=@_;
	$secs_per_day=60*60*24;

	# use Perl time functions - would be good to replace these Perl routines with epoch2str
	if ($zone eq "local") {
		($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time-$days_ago*$secs_per_day);
	}
	elsif ($zone eq "ut") {
		($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=gmtime(time-$days_ago*$secs_per_day);
	}
	else
	{
		die("get_time: zone must be 'local' or 'ut'\n");
	};

	# month returned by time has 0 for Jan, 1 for Feb,... make it 1 for Jan, 2 for Feb, ...
	$mon=$mon+1;

	# Hack required since perl function 'localtime' returns only 2 digit year
	$year = $year + 1900;

	# make sure month, day, hour & minute are all 2 digit strings
	if (length($mon)==1) { $mon = "0" . "$mon"; };
	if (length($mday)==1) { $mday = "0" . "$mday"; };
	if (length($hour)==1) { $hour = "0" . "$hour"; };
	if (length($min)==1) { $min = "0" . "$min"; };

	# return results
	return ($year,$mon,$mday,$hour,$min);
};



# given year,month,day,hour & min, return datenum (Matlab format)
# Usage: $dnum=date2dnum($year,$mon,$day,$hour,$min,$secs);
sub date2dnum {
	($yyyy,$mm,$dd,$hh,$mn,$ss)=@_;
	
	$Jan1st1990=726834;
	$dnum=$Jan1st1990;

	# convert to 4-digit year
	if (length($yyyy)!=4) {
		$yyyy=yy2yyyy($yyyy);
	}
	
	# add up days for intervening years
	$thisyear=$yyyy;
	for($yr=1990;$yr<$thisyear;$yr++){
		$ndays=days_per_year($yr);
		$dnum=$dnum+$ndays;
	}

	# add up days for intervening months
	$thismonth=$mm;
	for($mnth=1;$mnth<$thismonth;$mnth++){
		$ndays=days_per_month($mnth,$thisyear);
		$dnum=$dnum+$ndays;
	}

	# add up days in current month
	$dnum+=$dd-1;
print "$hh $mn $ss\n";

	# add up hours, minutes and seconds
	$dnum+=($hh/24+$mn/1440+$ss/86400);

	# return datenum
	return $dnum;
}


# function to return days per month
sub days_per_month {
	($mm,$yyyy)=@_;
	@days_a_month=(0,31,28,31,30,31,30,31,31,30,31,30,31);

	if($mm<1||$mm>12) {
		print "days_per_month: silly month $mm\n";
		exit(1);
	}
	$ndays=$days_a_month[$mm];
	if($mm==2 && $yyyy%4==0) {
		if(($yyyy%100==0)==($yyyy%400==0)) 
		{
			$ndays=29; 
		}
	}
	return $ndays;
}

# function to convert 2-digit year to 4-digit year
# valid only for 1900-2099
sub yy2yyyy {
	$yy=$_[0];
	if($yy>=0 && $yy<49) {
		$yyyy=$yy+2000;
	}
	else
	{
		if($yy=>50&&$yy<=99){
			$yyyy=$yy+1900;
		}
		else
		{
			if($yy<1900 || $yy>2099) {
				print "yy2yyyy: Error: yy on entry was $yy\n";				
				exit(1);
			}
			else
			{
				$yyyy=$yy;
			}
		}
	}
	return $yyyy;
}

# function to convert 4-digit year to 2-digit year
sub yyyy2yy {
	$yyyy=$_[0];
	$l=length($yyyy);
	$yy=substr($yyyy,$l-2,2);
	return $yy;
}

sub dnum2date {
	$dnum=$_[0];

	$yyyy=1990;$mm=1;$dd=1;
	$x0=726834;
	$x1=$x0+days_per_year($yyyy);
	while($x1<int($dnum)) {
		$yyyy++;
		$d=days_per_year($yyyy);
		$x0=$x1;
		$x1+=$d;
	}
	$x1=$x0+days_per_month($mm,$yyyy);
	while($x1<int($dnum)) {
		$mm++;
		$d=days_per_month($mm,$yyyy);
		$x0=$x1;
		$x1+=$d;
	}
	$dnum-=($x0-1);
	$dd=int($dnum);
	$dnum-=$dd;
	$dnum*=24;

	$hh=int($dnum);
	$dnum-=$hh;
	$dnum*=60;

	$mn=int($dnum);
	$dnum-=$mn;
	$dnum*=60;

	$ss=int($dnum);

	return($yyyy,$mm,$dd,$hh,$mn,$ss);
}

# function to return days per year
sub days_per_year {
	$yyyy=$_[0];

	if ($yyyy%4==0){
		$ndays=366; # leap year
	}
	else
	{
		$ndays=365; # non-leap year
	}
	return $ndays;
}



# function to calculate year corresponding to given datenumber 
sub dnum2yyyy {
	$dnum=$_[0];
	$yyyy=1995;
	$dnum-=166; # 166 is number of days in 1995 after 18 July
	while($dnum>0){
		$dnum-=days_per_year($yyyy);
		$yyyy++;
	}
	return $yyyy;
}




# add column of barwidth to infile, this is to get around a GMT bug
# Usage: add_barwidth_column($infile,$barwidth,$xfieldlength,$yfieldlength);

sub add_barwidth_column {
	($infile,$barwidth,$xfieldlength,$yfieldlength)=@_;
	open(IN,$infile);
	$outfile="$infile" . "tmp";
	open(OUT,">$outfile");
	while (read(IN,$x,$xfieldlength)){
		read(IN,$filler,1);
		read(IN,$y,$yfieldlength);
		read(IN,$filler,1);
		print OUT "$x $y $barwidth\n";
	};
	close(OUT);
	close(IN);
	system("mv $outfile $infile");
}



# given a 2-column daily file with format "%04d %11.4f\n" this works out min & max x&y values
# Usage: ($minx,$maxx,$miny,$maxy)=return_plot_limits($infile,$xfieldlength,$yfieldlength);

sub return_plot_limits {
	($infile,$xfieldlength,$yfieldlength)=@_;
	$minx=1e12;$maxx=-1e12;$miny=1e12;$maxy=-1e12;
	open(IN,$infile);
	while (read(IN,$x,$xfieldlength)){
		read(IN,$filler,1);
		read(IN,$y,$yfieldlength);
		read(IN,$filler,1);
		if($x>$maxx) {$maxx=$x};
		if($x<$minx) {$minx=$x};
		if($y>$maxy) {$maxy=$y};
		if($y<$miny) {$miny=$y};
	};
	close(IN);
	$minx=~ s/ //g;
	$maxx=~ s/ //g;
	$miny=~ s/ //g;
	$maxy=~ s/ //g;
	return ($minx,$maxx,$miny,$maxy);
}



# cumulate time series data
# Usage: $total=cumulate_data($infile,$outfile);

sub cumulate_data {
	$infile=$_[0];
	$outfile=$_[1];
	open(IN,$infile);
	open(OUT,">$outfile");
	$total=0;
	while (read(IN,$x,11)){
		read(IN,$filler,1);
		read(IN,$y,9);
		read(IN,$filler,1);
		$total=$total+$y;
		print OUT "$x $total\n";
	};
	close(OUT);
	close(IN);
	return $total;
}


# convert subclass ('t','h','l', 'e' or 'r') to eventtype
# Usage: $eventtype=subclass2eventtype($subclass);

sub subclass2eventtype {
	$subclass = $_[0];
	
	if ($subclass eq "r") {
		$eventtype="rockfalls";
	}
	else
	{
		if ($subclass eq "e") {
			$eventtype="lprfs";
		}
		else
		{
			if ($subclass eq "h") {
				$eventtype="hybrids";
			}
			else
			{

				if ($subclass eq "l") {
					$eventtype="lps";
				}
				else
				{
					$eventtype="vts";
				}
			}
		}
	}
	return $eventtype;
}



# Work out a sensible xinterval based on the number of days of data plotted
# Usage: $xinterval=calc_xinterval($numdays);

sub calc_xinterval {
	$numdays=$_[0];

	if ($numdays<2) {
		$xinterval=0.2;
	}
	else
	{
		if ($numdays<5) {
			$xinterval=0.5;
		}
		else
		{
			if ($numdays<12) {
				$xinterval=1;
			}
			else
			{
				if ($numdays<31) {
					$xinterval=3;
				}
				else
				{
					if ($numdays<100) {
						$xinterval=10;
					}
					else
					{
						$xinterval=28;
					};
				};
			}
		}
	}
	return $xinterval;
}
