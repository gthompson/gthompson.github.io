<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  	<title>Glenn Thompson - Homepage</title>
  	 <link rel="stylesheet" type="text/css" href="glenn.css" media="all" />
  	 
  	 
</head>
<body>
	<?php
		include("topmenu.php");
	?>
	
	
	<div id="content">
		
	<!-- 
	Available styles
	<h2>, <h3>, <strong>, <a>
	-->
	<h3>AVO Projects</h3>
	<ul>
	<li><a href="projects/Shishaldin1999/shishaldin.html">Volcanic Tremor at Shishaldin Volcano, 1999</a></li>
	<li><a href="projects/IceWeb/iceweb.html">The IceWeb project (March 1998 - October 1999)</a></li>

<!--	<li><a href="projects/">Triggering of volcanic eruptions by earthquakes (1999)</a></li>
	<li><a href="projects/">The AVO Swarm Alarm System (2009)</a></li>
	<li><a href="projects/">AVO Seismology Software Development Plan (2009)</a></li>
	<li><a href="projects/">IceWeb2 (2009)</a></li>
	<li><a href="projects/">Application of tremor and swarm alarm systems to the eruption at Redoubt Volcano, 2009</a></li>	
	-->
	</ul>
	
<!--	
	<h3>AEIC Projects</h3>
	<ul>
	<li><a href="projects/">The AEIC Antelope-ShakeMap Interface</a></li>
	<li><a href="projects/">Earthquake Notification at Emergency Operations Centers</a></li>
	<li><a href="projects/">The Trans-Alaska Pipeline Early Warning System</a></li>
	<li><a href="projects/">dbevents_aeic</a></li>
	</ul>
	
	<h3>MVO Projects</h3>
	<ul>
	<li><a href="projects/">Banded Tremor at Soufriere Hills Volcano</a></li>
	<li><a href="projects/">Re-engineering the MVO seismic monitoring systems</a></li>
	<li><a href="projects/">Upgrading to Earthworm and QNX Seislog</a></li>
	<li><a href="projects/">Merging the analog and digital seismic networks</a></li>
	<li><a href="projects/">Estimating magnitudes for long-period earthquakes and rockfalls</a></li>
	<li><a href="projects/">Upgrading the digital seismic network at MVO</a></li>
	<li><a href="projects/">Data recovery and management at MVO</a></li>
	<li><a href="projects/">Modernising the analysis of seismic data at MVO</a></li>	
	<li><a href="projects/">Web-based seismic monitoring at MVO</a></li>
	<li><a href="projects/">Rainfall-induced collapses of lava domes at Soufriere Hills Volcano</a></li>	
	<li><a href="projects/">Locating rockfalls and pyroclastic flows at Soufriere Hills Volcano</a></li>
	<li><a href="projects/">A comparison of dome-collapse seismicity at Soufriere Hills Volcano</a></li>
	</ul>
	
	<h3>BGS Projects</h3>
	<ul>
	<li><a href="projects/">Beach Sediment Thickness - seismic refraction and resistivity</a></li>
	<li><a href="projects/">Migration of geophysical software from IRIX to MS-Windows</a></li>
	</ul>
-->
	
	</div>
<p id="footer">
<SCRIPT language="JavaScript" type="text/javascript">
//  update - from http://rainbow.arch.scriptmania.com/scripts
<!--
function getLongDateString()
{	//method defined on class Date.
	//Returns a date string of the form: Day DD Month,YYYY
	//(e.g. Sunday 27 September, 1998)
	monthNames = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
dayNames = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
	dayOfWeek = this.getDay();
	day = dayNames[dayOfWeek];
	dateOfMonth = this.getDate();
monthNo = this.getMonth();
	month = monthNames[monthNo];
year = this.getYear();
	if (year < 2000)
year = year + 1900;
dateStr = day+" "+dateOfMonth+" "+month+", "+year;
	return dateStr;
}
//register the  method in the class Date
Date.prototype.getLongDateString=getLongDateString;

function DocDate()
{ //return the document modification date (excl.time)
//as a string
	DateTimeStr = document.lastModified;
	secOffset = Date.parse(DateTimeStr);
	if (secOffset == 0 || secOffset == null) //Opera3.2
			 dateStr = "Unknown";
	else
	{
		aDate = new Date();
		aDate.setTime(secOffset);
		//use method defined above
		datestr = aDate.getLongDateString();
	}
	return dateStr;
}

document.write("Last Update: ");
document.writeln(DocDate(),"");
// -->
</script>
	</p>
</div>
</body>
</html>
